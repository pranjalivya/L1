package opencart;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class NodeHub {
	static WebDriver driver;
	static String baseurl;
	static String nodeurl;
	
	@Test
	public static void asd() throws MalformedURLException, InterruptedException
	{
		
		nodeurl="http://10.102.52.83:5666/wd/hub";
		new DesiredCapabilities();
		 DesiredCapabilities t = DesiredCapabilities.chrome();
	
		t.setBrowserName("chrome");
		t.setPlatform(Platform.WINDOWS);
		driver= new RemoteWebDriver(new URL (nodeurl),t);
		//test
		
		//opens the open cart link link
				driver.get("https://demo.opencart.com/");
				
				String s =driver.getTitle();
				String s1 ="Your Store";
				
				//verify your store tittle
				if(s.equals(s1))
					System.out.println("Title is correct");
				else
					System.out.println("Title is incorrect");
				
				//wait for page to load
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				//count the no of links
				int count = 0; 
				List<WebElement> links = driver.findElements(By.xpath("//body"));    //Identify the number of Link on webpage and assign into Webelement List 
		        
		        count = links.size();  
		        System.out.println("No. of links available = "+ count);
		        
		        //click on My account
		        driver.findElement(By.xpath("//div[@id='top-links']/ul/li[2]/a/i")).click();
		        
		        //select register
		        driver.findElement(By.cssSelector("ul.dropdown-menu.dropdown-menu-right > li > a")).click();
		        
				//fill all mandatory fields
		        
		     
		        driver.findElement(By.cssSelector("#input-email")).sendKeys("pranjali@capgemini.com");
		        driver.findElement(By.xpath("//input[@id='input-telephone']")).sendKeys("9869690179");
		        
		       

			    Thread.sleep(2000);
			    //click on continue
			    driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
			    

			    //verify incomplete fields error messages
			    //first name
			    if(driver.findElement(By.id("input-firstname")).getText().contentEquals("First Name must be between 1 and 32 characters!"))
			    {
			    	System.out.println("first name error message is correct");
			    }
			    else
			    {
			    	System.out.println("first name error message is incorrect");
			    }
			    //last name
			    if(driver.findElement(By.name("lastname")).getText().contentEquals("Last Name must be between 1 and 32 characters!"))
			    {
			    	System.out.println("last name error message is correct");
			    }
			    else
			    {
			    	System.out.println("last name error message is incorrect");
			    }
			    //password verification
			    driver.findElement(By.id("input-password")).clear();
			    driver.findElement(By.id("input-password")).sendKeys("Pranjali123");
			    driver.findElement(By.id("input-confirm")).clear();
			    driver.findElement(By.name("confirm")).sendKeys("123");
			    Thread.sleep(2000);
			    //click on continue
			    driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
			    
			    if(driver.findElement(By.xpath("//div[@id='content']/form/fieldset[2]/div[2]/div/div")).getText().contentEquals("Password confirmation does not match password!"))
			    {
			    	System.out.println("password not matched error message is correct");
			    }
			    else
			    {
			    	System.out.println("password not matched error message is correct");
			    }
			    //enter the mandatory fields
			    driver.findElement(By.id("input-firstname")).clear();
			    driver.findElement(By.id("input-firstname")).sendKeys("Pranjali");
			    driver.findElement(By.id("input-lastname")).clear();
			    driver.findElement(By.id("input-lastname")).sendKeys("Vyavaharkar");
			    driver.findElement(By.id("input-confirm")).clear();
			    driver.findElement(By.id("input-confirm")).sendKeys("123Pranjali");
			    //click on radio button and continue
			    driver.findElement(By.name("newsletter")).click();
			    driver.findElement(By.xpath("(//input[@name='newsletter'])[2]")).click();
			    driver.findElement(By.name("agree")).click();
			    
			    Thread.sleep(2000);
			    driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
			    
			    Thread.sleep(2500);
			    //account successfully created
			    if(driver.findElement(By.cssSelector("#content > h1")).getText().contentEquals("Your Account Has Been Created!"))
			    {
			    	System.out.println("Account message is correct");
			    
			    }
			    else
			    {
			    	System.out.println("Account message is incorrect");
			    }
			    
			    //click on phones and pda
			    driver.findElement(By.linkText("Phones & PDAs")).click();
			    Thread.sleep(2000);
			    driver.findElement(By.cssSelector("div.image > a > img.img-responsive")).click();

			    if(driver.findElement(By.cssSelector("div.col-sm-4 > h1")).getText().contentEquals("HTC Touch HD"))
			    {
			    	System.out.println("HTC Touch HD is correct");
			    }
			    else
			    {
			    	System.out.println("Text HTC Touch HD is incorrect");
			    }
			    Thread.sleep(1000);
			    //click back button
			    driver.navigate().back();
			    Thread.sleep(1000);
			    //add to cart
			    driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/button[1]")).click();
			    
			    Thread.sleep(3000);
			    if(driver.findElement(By.xpath("//div[@id='product-category']/div")).getText().contentEquals("Success: You have added HTC Touch HD to your shopping cart!\n�"))
			    {
			    	System.out.println("add to cart messagecorrect");
			    }
			    else
			    {
			    	System.out.println("add to cart message in coorect");
			    }
			   //brands
			    driver.findElement(By.linkText("Brands")).click();
			    if(driver.getTitle().contentEquals("Find Your Favorite Brand"))
			    {
			    	System.out.println("Brand message correct");
			    }
			    else
			    {
			    	System.out.println("Brand message correct");
			    }
			    
			    //canon
			    driver.findElement(By.linkText("Canon")).click();
			    if(driver.findElement(By.cssSelector("h2")).getText().contentEquals("Canon"))
			    {
			    	System.out.println("Heading Verified 	Cannon");
			    }
			    else
			    {
			    	System.out.println("Heading (Cannon) Not Verified");
			    }

			    driver.findElement(By.xpath("(//button[@type='button'])[11]")).click();
			    Thread.sleep(3000);
			    if(driver.findElement(By.xpath("//div[@id='product-manufacturer']/div")).getText().contentEquals("Success: You have added Canon EOS 5D to your wish list!\n�"))
			    {
			    	System.out.println("Product Added Succesfully to WishList Text Verified");
			    }
			    else if(driver.findElement(By.xpath("//div[@id='product-manufacturer']/div")).getText().contentEquals("You must login or create an account to save Canon EOS 5D to your wish list!\n�"))
			    {
			    	System.out.println("Product Added Succesfully to WishList Text Verified");
			    }
			    else
			    {
			    	System.out.println("Product Added Succesfully to WishList Text Not Verified");
			    }
			    
			    driver.findElement(By.linkText("Wish List")).click(); 
			    WebDriverWait wait = new WebDriverWait(driver, 10);
			    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Continue")));
			    driver.findElement(By.linkText("Continue")).click();
			    driver.close();
			    System.out.println("Browser Closed.");

			  
			   
	}
}

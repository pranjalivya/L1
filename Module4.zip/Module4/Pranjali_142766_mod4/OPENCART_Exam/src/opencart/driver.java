package opencart;

public class driver {

	public static String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Object manage() {
		// TODO Auto-generated method stub
		return null;
	}

}

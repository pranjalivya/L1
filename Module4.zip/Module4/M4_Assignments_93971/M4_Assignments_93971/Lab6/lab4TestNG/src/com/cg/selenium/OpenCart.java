package com.cg.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class OpenCart {
	WebDriver driver;
	@Test(priority = 1)
	  public void verifyDetails() throws InterruptedException {
		  
		  driver.findElement(By.cssSelector("a[title='My Account']")).click();
		  driver.findElement(By.xpath("//a[contains(text(),'Login')]")).click();
		  driver.findElement(By.name("email")).sendKeys("abgjkhsgkcd@gmail.com");
		  driver.findElement(By.name("password")).sendKeys("123pass");
		  driver.findElement(By.cssSelector("input[value=Login]")).click();
		  driver.findElement(By.linkText("Components")).click();
		  driver.findElement(By.linkText("Monitors (2)")).click();
		  Select select = new Select(driver.findElement(By.cssSelector("select#input-limit")));
		  select.selectByVisibleText("25");
		  driver.findElement(By.xpath("//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
		  Thread.sleep(2000);
		  	  }
	  @Test(priority = 2)
	  public void verifyMessage() throws InterruptedException {
		  
		  driver.findElement(By.xpath("//*[@id='content']/div[1]/div[2]/div[1]/button[1]")).click();;
		  Thread.sleep(2000);
		  String str = driver.findElement(By.cssSelector("div#product-product > div.alert.alert-success.alert-dismissible")).getText();
		  Assert.assertTrue(str.contains("Success: You have added Apple Cinema 30\" to your wish list!"));
	  }
	  
	  @Test(priority = 3)
	  public void verifyMessage2() throws InterruptedException {
		  driver.findElement(By.cssSelector("input[name='search']")).sendKeys("Mobile");
		  driver.findElement(By.cssSelector("div#search > span > button")).click();
		  Thread.sleep(2000);
		  driver.findElement(By.cssSelector("input#description")).click();
		  driver.findElement(By.cssSelector("input#button-search")).click();
		  Thread.sleep(1000);
		  driver.findElement(By.linkText("HTC Touch HD")).click();
		  Thread.sleep(1000);
		  driver.findElement(By.cssSelector("input[name='quantity']")).clear();
		  driver.findElement(By.cssSelector("input[name='quantity']")).sendKeys("3");
		  driver.findElement(By.cssSelector("button#button-cart")).click();
		  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);	
		  String str = driver.findElement(By.cssSelector("div#product-product > div.alert.alert-success.alert-dismissible")).getText();
		  Assert.assertTrue(str.contains("Success: You have added HTC Touch HD to your shopping cart!"));
	  }
	  @Test(priority = 4)
	  public void verifyMobile() throws InterruptedException {
		  driver.findElement(By.cssSelector("div#cart > button")).click();
		  String str = driver.findElement(By.cssSelector("#cart > ul > li:nth-child(1) > table > tbody > tr > td.text-left > a")).getText();
		  Assert.assertEquals(str,"HTC Touch HD");
	  }
	  @Test(priority = 5)
	  public void verifyLogout() throws InterruptedException {
		  driver.findElement(By.cssSelector("div#cart > ul > li:nth-child(2) > div > p > a:nth-child(2)")).click();
		  Thread.sleep(2000);
		  driver.findElement(By.cssSelector("a[title='My Account']")).click();
		  driver.findElement(By.linkText("Logout")).click();
		  Thread.sleep(2000);
		  WebElement element = driver.findElement(By.cssSelector("div#content > h1"));
		  Assert.assertEquals(element.getText(),"Account Logout");
		  driver.findElement(By.cssSelector("#content > div > div > a")).click();
	  }
	  
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
	  driver = driver = new ChromeDriver();
	  driver.get("http://demo.opencart.com/");
  }

  @AfterTest
  public void afterTest() {
	  driver.close();
  }

}

package com.cg.selenium;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;


public class OpenCart {
	WebDriver driver;
  @Test(priority = 0)
  public void verifyTitle() {
	  Assert.assertEquals("Your Store", driver.getTitle());
  }
  @Test(priority = 1)
  public void verifyHeading() throws InterruptedException {
	  Thread.sleep(2000);
	  driver.findElement(By.cssSelector("a[title='My Account']")).click();
	  driver.findElement(By.xpath("//a[contains(text(),'Register')]")).click();
	  Assert.assertEquals("Register Account", driver.findElement(By.cssSelector("div#content > h1")).getText());
  }
  @Test(priority = 2)
  public void verifyWarning() {
	  driver.findElement(By.cssSelector("input[type=submit]")).click();
	  String warning = driver.findElement(By.cssSelector("div.alert.alert-danger.alert-dismissible")).getText();
	  Assert.assertEquals("Warning: You must agree to the Privacy Policy!",warning);
  }
  //Part 2
  @Test(priority = 3)
  public void verifyFNameLImit() {
	  driver.findElement(By.name("firstname")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
	  driver.findElement(By.cssSelector("input[type=submit]")).click();
	  String warning = driver.findElement(By.xpath("//*[@id='account']//div[2]//div//div")).getText();
	  Assert.assertEquals("First Name must be between 1 and 32 characters!",warning);  
  }
  @Test(priority = 4)
  public void verifyLNameLimit() {
	  driver.findElement(By.name("lastname")).sendKeys("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
	  driver.findElement(By.cssSelector("input[type=submit]")).click();
	  String warning = driver.findElement(By.xpath("//*[@id='account']//div[3]//div//div")).getText();  
	  Assert.assertEquals("Last Name must be between 1 and 32 characters!",warning);  
  }
  
  @Test(priority = 5)
  public void restprocess() throws InterruptedException {
	  driver.findElement(By.name("firstname")).clear();
	  driver.findElement(By.name("lastname")).clear();
	  driver.findElement(By.name("firstname")).sendKeys("abcd");
	  driver.findElement(By.name("lastname")).sendKeys("abcd");
	  driver.findElement(By.name("email")).sendKeys("abgjkhsgkcd@gmail.com");
	  driver.findElement(By.name("telephone")).sendKeys("98284567");
	  driver.findElement(By.name("password")).sendKeys("123pass");
	  driver.findElement(By.name("confirm")).sendKeys("123pass");
	  driver.findElement(By.name("telephone")).sendKeys("98284567");
	  driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[1]/input")).click();
	  driver.findElement(By.name("agree")).click();
	  driver.findElement(By.cssSelector("input[type=submit]")).click();
	  driver.findElement(By.linkText("Continue")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.linkText("View your order history")).click();
	  
  }
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
	  driver = driver = new ChromeDriver();
	  driver.get("http://demo.opencart.com/");
	  
	  
  }

  @AfterTest
  public void afterTest() {
  }

}

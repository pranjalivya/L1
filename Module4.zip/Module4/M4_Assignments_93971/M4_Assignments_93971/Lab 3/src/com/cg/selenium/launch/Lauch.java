package com.cg.selenium.launch;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lauch {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		driver.manage().window().maximize();
		if(driver.getTitle().equals("Your Store"))
		{
			driver.findElement(By.cssSelector("#top-links > ul > li.dropdown > a > span.hidden-xs.hidden-sm.hidden-md")).click();
			Thread.sleep(3000);
			driver.findElement(By.cssSelector("#top-links > ul > li.dropdown.open > ul > li:nth-child(1) > a")).click();
			if(driver.getTitle().equals("Register Account"))
			{
				((JavascriptExecutor) driver).executeScript("alert('Verification done')");
				driver.switchTo().alert().accept();
				driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
				
				if(driver.findElement(By.xpath("//*[@id='account-register']/div[1]")).getText().contains("Warning: You must agree to the Privacy Policy!")){
					((JavascriptExecutor) driver).executeScript("alert('Verification done')");
				driver.switchTo().alert().accept();

				
				
				driver.findElement(By.name("firstname")).sendKeys("qwertyuioplkjhgfdsazxcvbnmlkjhgfd");
				if(driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div")).getText().contains("First Name must be between 1 and 32 characters!")){
					((JavascriptExecutor) driver).executeScript("alert('Verification done')");
				driver.switchTo().alert().accept();
				driver.findElement(By.name("firstname")).clear();
				driver.findElement(By.name("firstname")).sendKeys("Shobhit");
				}
				else{
					((JavascriptExecutor) driver).executeScript("alert('Does not verify the condition')");
					driver.switchTo().alert().accept();
				}
				
				
			driver.findElement(By.id("input-lastname")).sendKeys("qazxswedcvfrtgbnhyujmkiolpzxcvbnm");
			if(driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div")).getText().contains("Last Name must be between 1 and 32 characters!")){
				((JavascriptExecutor) driver).executeScript("alert('Verification done')");
			driver.switchTo().alert().accept();
			driver.findElement(By.id("input-lastname")).clear();
			driver.findElement(By.id("input-lastname")).sendKeys("Solanki");
			}
			else{
				((JavascriptExecutor) driver).executeScript("alert('Does not verify the condition')");
				driver.switchTo().alert().accept();
			}
			
			
			driver.findElement(By.name("email")).sendKeys("shobhitsolanki1234@gmail.com");
			
			
			
			driver.findElement(By.cssSelector("#input-telephone")).sendKeys("965810036996587412365478963258741365");
			if(driver.findElement(By.xpath("//*[@id='account']/div[5]/div/div")).getText().contains("Telephone must be between 3 and 32 characters!")){
				((JavascriptExecutor) driver).executeScript("alert('Verification done')");
			driver.switchTo().alert().accept();
			driver.findElement(By.cssSelector("#input-telephone")).clear();
			driver.findElement(By.cssSelector("#input-telephone")).sendKeys("9658100369");
			}
			else{
				((JavascriptExecutor) driver).executeScript("alert('Does not verify the condition')");
				driver.switchTo().alert().accept();
			}
			
			driver.findElement(By.cssSelector("#input-password")).sendKeys("ipsa12345");
			driver.findElement(By.name("confirm")).sendKeys("ipsa12345");
			driver.findElement(By.name("agree")).click();
			driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();	
					
			{
					((JavascriptExecutor) driver).executeScript("alert('Does not verify the condition')");
					driver.switchTo().alert().accept();
				}}
			else
			{
				System.out.println("Ur on wrong page\n");
				((JavascriptExecutor)driver).executeScript("alert('You are on wrong Page. please enter a valid URL')");
			}
			
			
			
		}


	}

	}}

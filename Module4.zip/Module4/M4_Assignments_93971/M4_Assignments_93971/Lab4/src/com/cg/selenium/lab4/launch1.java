package com.cg.selenium.lab4;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class launch1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		driver.manage().window().maximize();
		driver.findElement(By.cssSelector("#top-links > ul > li.dropdown > a > span.hidden-xs.hidden-sm.hidden-md")).click();
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("#top-links > ul > li.dropdown.open > ul > li:nth-child(2) > a")).click();
		driver.findElement(By.name("email")).sendKeys("et14@gmail.com");
		driver.findElement(By.name("password")).sendKeys("ipsa12345");
		driver.findElement(By.cssSelector("#content > div > div:nth-child(2) > div > form > input")).click();
		driver.findElement(By.cssSelector("#menu > div.collapse.navbar-collapse.navbar-ex1-collapse > ul > li:nth-child(3) > a")).click();
		driver.findElement(By.cssSelector("#menu > div.collapse.navbar-collapse.navbar-ex1-collapse > ul > li:nth-child(3) > div > div > ul > li:nth-child(2) > a")).click();
		Select select= new Select(driver.findElement(By.id("input-limit")));
		select.selectByIndex(1);
		driver.findElement(By.cssSelector("#content > div:nth-child(5) > div:nth-child(1) > div > div:nth-child(2) > div.button-group > button:nth-child(1) > span")).click();
//		driver.findElement(By.xpath("//*[@id='content']/div[1]/div[1]/ul[2]/li[2]/a")).click();
		Thread.sleep(4000);
		driver.findElement(By.cssSelector("#content > div:nth-child(1) > div.col-sm-8 > ul.nav.nav-tabs > li:nth-child(2) > a")).click();
		if(driver.findElement(By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[1]")).getText().equals("Clockspeed")){
			if(driver.findElement(By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[2]")).getText().equals("100mhz")){
				System.out.println("Success");
				Thread.sleep(3000);
			}
		}
			
		
		driver.findElement(By.cssSelector("#content > div:nth-child(1) > div.col-sm-4 > div.btn-group > button:nth-child(1)")).click();
		Thread.sleep(3000);
		if(driver.findElement(By.xpath("//*[@id='product-product']/div[1]")).getText().contains("Success")){
			((JavascriptExecutor) driver).executeScript("alert('Success')");
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
		}
		else{
			((JavascriptExecutor) driver).executeScript("alert('Failed')");
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
		}
		driver.findElement(By.cssSelector("#search > input")).sendKeys("Mobile");
		driver.findElement(By.cssSelector("#search > span > button")).click();
		driver.findElement(By.id("description")).click();
		driver.findElement(By.cssSelector("#button-search")).click();
		driver.findElement(By.cssSelector("#content > div:nth-child(8) > div:nth-child(1) > div > div:nth-child(2) > div.caption > h4 > a")).click();
		driver.findElement(By.id("input-quantity")).clear();
		driver.findElement(By.id("input-quantity")).sendKeys("3");
		driver.findElement(By.id("button-cart")).click();
		Thread.sleep(3000);
		if(driver.findElement(By.xpath("//*[@id='product-product']/div[1]")).getText().contains("Success: You have added HTC Touch HD to your shopping cart!")){
			((JavascriptExecutor) driver).executeScript("alert('Success')");
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
		}
		else{
			((JavascriptExecutor) driver).executeScript("alert('Failed')");
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
		}
		
		driver.findElement(By.cssSelector("#cart-total")).click();
		driver.findElement(By.cssSelector("#cart > ul > li:nth-child(2) > div > p > a:nth-child(1) > strong")).click();
		
		
		if(driver.findElement(By.xpath("//*[@id='content']/form/div/table/tbody/tr/td[2]/a")).getText().contains("HTC Touch HD ***")){
			((JavascriptExecutor) driver).executeScript("alert('Success')");
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
		}
		else{
			((JavascriptExecutor) driver).executeScript("alert('Failed')");
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
		}
		
		
		driver.findElement(By.cssSelector("#content > div.buttons.clearfix > div.pull-right > a")).click();
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/span[1]")).click();
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[5]/a")).click();
		
		
		if(driver.findElement(By.xpath("//*[@id='content']/h1")).getText().contains("Account Logout")){
			((JavascriptExecutor) driver).executeScript("alert('Success')");
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
		}
		else{
			((JavascriptExecutor) driver).executeScript("alert('Failed')");
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
		}
		
		
		driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
	}

}

package org.example;

public class WithNodeHub {

}

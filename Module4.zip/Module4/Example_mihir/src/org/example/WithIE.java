package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class WithIE
{
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.internetexplorer.driver","D:/MJ/VnV Auto & Man Testing/IEDriverServer_Win32_3.8.0/IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();
		
		String baseUrl = "https://demo.opencart.com/";
		
		String expectedTitle = "Your Store";
		String actualTitle = "";

		// launch Firefox and direct it to the Base URL
		driver.get(baseUrl);
		// get the actual value of the title
		actualTitle = driver.getTitle();
		
		//Checking page Title
		if (actualTitle.contentEquals(expectedTitle))
			{
				System.out.println("Your Title : Test Passed!");
			} 
		else
			{
				System.out.println("Your Title : Test Failed");
			}
		
		//Clicking the Items button on the WebPage
		driver.findElement(By.cssSelector(".btn.btn-inverse.btn-block.btn-lg.dropdown-toggle")).click();
		
		//Checking the Message displayed after Items button is clicked
		if(driver.findElement(By.xpath(".//*[@id='cart']/ul/li/p")).getText().equals("Your shopping cart is empty!"))
			System.out.println("Your shopping cart is empty!");
		else
			System.out.println("No Message Shown");
		
		//Clicking the Contacts button
		driver.findElement(By.cssSelector(".fa.fa-phone")).click();
		
		//Verifying the Heading of the Contacts Page
		String a = driver.findElement(By.linkText("Contact Us")).getText();
		String b = "Contact Us";
		
		if(a.contentEquals(b))
		{
		System.out.println("Heading is : Contact Us");
		}
		else
		{
			System.out.println("Wrong Heading");
		}
		
		//Verifying default address under Our Location Section
		String c = driver.findElement(By.linkText("Your Store")).getText();
		String d = "Your Store";
		
		if(c.contentEquals(d))
		{
			System.out.println("Address 1");
		}
		else
		{
			System.out.println("Wrong Address");
		}
		
		String e = driver.findElement(By.cssSelector(".col-sm-3>strong")).getText();
		String f = "Telephone";
		
		if(e.contentEquals(f))
		{
			System.out.println("123456789");
		}
		else
		{
			System.out.println("Wrong Telephone");
		}
		
		//Entering Details in Contact Form
		driver.findElement(By.id("input-name")).sendKeys("Mihir Jain");
		
		//Entering Invalid Email
		driver.findElement(By.name("email")).sendKeys("mihir2916gmail.com");
		
		//Submitting the Form with Invalid Email
		driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input")).click();
		
		//Verifying Error Message
		if(driver.findElement(By.xpath(".//*[@id='content']/form/fieldset/div[2]/div/div")).getText().equals("E-Mail Address does not appear to be valid!"))
			System.out.println("E-Mail Address does not appear to be valid!");
		else
			System.out.println("Invalid email");
		
		//Entering Valid Email Addresss
		driver.findElement(By.name("email")).sendKeys("mihir2916@gmail.com");
		
		//Entering Enquiry Details 
		driver.findElement(By.id("input-enquiry")).sendKeys("General Enquiry");
		
		//Submitting the form
		driver.findElement(By.xpath("//input[@value='Submit']")).click();
		
		//Clicking on Continue Button
		driver.findElement(By.linkText("Continue")).click();
		
		//Clicking on Brands under Extras
		driver.findElement(By.linkText("Brands")).click();
		
		//Verifying Heading of the Brands Page
		String g = driver.findElement(By.cssSelector("#content > h1")).getText();
		String h = "Find Your Favorite Brand";
		
		if(g.contentEquals(h))
		{
			System.out.println("Find Your Favorite Brand");
		}
		else
		{
			System.out.println("Heading does not match");
		}
		
		//Click on Sony 
		driver.findElement(By.linkText("Sony")).click();
		
		//Add to Cart option Selected
		driver.findElement(By.xpath("(//button[@type='button'])[9]")).click();
		
		//Verifying Success Message
		String i = driver.findElement(By.xpath("//div[@id='product-manufacturer']/div")).getText();
		String j = "Success:You have added Sony VAIO to your shopping cart!";
		
		if(i.contentEquals(j))
		{
			System.out.println(" Success: You have added Sony VAIO to your shopping cart! ");
		}
		else
		{
			System.out.println("Success Message does not match");
		}
		
		
	}
}
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class NodeHub {
	static WebDriver d;
	static String baseurl;
	static String nodeurl;
	
	@Test
	public static void asd() throws MalformedURLException
	{
		baseurl="file:///D:/MJ/VnV%20Auto%20&%20Man%20Testing/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lab%20Files/Lab%20Files/LoginPage.html";
		nodeurl="http://10.102.57.7:5666/wd/hub";
		new DesiredCapabilities();
		DesiredCapabilities t = DesiredCapabilities.firefox();
		t.setBrowserName("firefox");
		t.setPlatform(Platform.WINDOWS);
		d= new RemoteWebDriver(new URL (nodeurl),t);
		//test
		
		String b="https://demo.opencart.com/";
		d.get(b);
		String s=d.getTitle();
		String s1="Your Store";

		if(s.equals(s1))
			System.out.println("Homepage Title ok");
		else
			System.out.println("Homepage Title not ok");
		
		d.findElement(By.xpath(".//*[@id='cart']/button")).click();
		
	
		if(d.findElement(By.xpath(".//*[@id='cart']/ul/li/p")).getText().equals("Your shopping cart is empty!"))
			System.out.println("Item Message is ok");
		else
			System.out.println("Item message is not ok");
		
		d.findElement(By.xpath("html/body/footer/div/div/div[2]/ul/li[1]/a")).click();
		
	
		if(d.findElement(By.xpath(".//*[@id='content']/h1")).getText().equals("Contact Us"))
			System.out.println("Contact heading is ok");
		else
			System.out.println("Contact heading is not ok");
		
		if(d.findElement(By.xpath(".//*[@id='content']/div/div/div/div[1]/address")).getText().equals("Address 1"))
			System.out.println("Default address is ok");
		else
			System.out.println("Default address is not ok");
		
		d.findElement(By.xpath(".//*[@id='input-name']")).sendKeys("Pinak");
		d.findElement(By.xpath(".//*[@id='input-email']")).sendKeys("asdgmail.com");
		
		d.findElement(By.xpath(".//*[@id='content']/form/div/div/input")).click();
		
		

		if(d.findElement(By.xpath(".//*[@id='content']/form/fieldset/div[2]/div/div")).getText().equals("E-Mail Address does not appear to be valid!"))
			System.out.println("invalid email error msg is ok");
		else
			System.out.println("invalid email error msg is not ok");
		
		
		
	}
	
}
